const { cmd } = require("../lib/commands")

cmd({
    pattern: "ping",
    function: async ({ sock, msg }) => {
        await sock.sendMessage(msg.key.remoteJid, { text: "Pong!" })
    }
})