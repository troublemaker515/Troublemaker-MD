const { cmd } = require("../lib/commands")

const truths = ["Biggest fear?", "Secret crush?", "Biggest lie?"]

cmd({
    pattern: "truth",
    function: async ({ sock, msg }) => {
        const q = truths[Math.floor(Math.random() * truths.length)]
        await sock.sendMessage(msg.key.remoteJid, { text: q })
    }
})