const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys")
const P = require("pino")
const fs = require("fs")

const commands = require("./lib/commands")

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState("session")

    const sock = makeWASocket({
        auth: state,
        logger: P({ level: "silent" })
    })

    sock.ev.on("creds.update", saveCreds)

    fs.readdirSync("./commands").forEach(file => {
        require(`./commands/${file}`)
    })

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message || msg.key.fromMe) return

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text
        if (!text) return

        const prefix = "."
        if (!text.startsWith(prefix)) return

        const args = text.slice(prefix.length).trim().split(" ")
        const cmdName = args.shift().toLowerCase()

        const command = commands.find(c => c.pattern === cmdName)
        if (!command) return

        try {
            await command.function({ sock, msg, args })
        } catch (e) {
            console.log("Error:", e)
        }
    })

    sock.ev.on("connection.update", ({ connection }) => {
        if (connection === "open") console.log("Bot Connected")
        if (connection === "close") startBot()
    })
}

startBot()